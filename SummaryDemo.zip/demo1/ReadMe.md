app:负责管理各个业务组件和打包apk,没有具体业务功能

lib_common:核心公用组件
lib_refresh:上下拉刷新组件
lib_api:网络请求组件