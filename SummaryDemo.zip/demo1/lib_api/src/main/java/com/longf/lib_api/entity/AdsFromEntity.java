package com.longf.lib_api.entity;

/**
 * 广告类型
 */
public class AdsFromEntity {
    /**
     * froms : iclick
     */

    private String froms;

    public String getFroms() {
        return froms;
    }

    public void setFroms(String froms) {
        this.froms = froms;
    }
}
