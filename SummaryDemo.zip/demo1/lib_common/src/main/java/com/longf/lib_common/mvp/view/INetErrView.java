package com.longf.lib_common.mvp.view;

public interface INetErrView {
    //显示网络错误的View
    void showNetWorkErrView();
    //隐藏网络错误的View
    void hideNetWorkErrView();
}
