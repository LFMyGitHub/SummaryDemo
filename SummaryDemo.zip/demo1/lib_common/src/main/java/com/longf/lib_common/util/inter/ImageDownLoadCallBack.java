package com.longf.lib_common.util.inter;

public interface ImageDownLoadCallBack {
    void onDownLoadSuccess();
    void onDownLoadFailed();
}
