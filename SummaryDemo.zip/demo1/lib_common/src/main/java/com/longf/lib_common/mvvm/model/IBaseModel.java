package com.longf.lib_common.mvvm.model;

public interface IBaseModel {
    void onCleared();
}
