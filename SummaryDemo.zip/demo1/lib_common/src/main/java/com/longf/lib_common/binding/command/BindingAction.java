package com.longf.lib_common.binding.command;

public interface BindingAction {
    void call();
}
