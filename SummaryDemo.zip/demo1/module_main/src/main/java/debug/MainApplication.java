package debug;

import com.longf.lib_common.BaseApplication;

public class MainApplication extends BaseApplication {
}
