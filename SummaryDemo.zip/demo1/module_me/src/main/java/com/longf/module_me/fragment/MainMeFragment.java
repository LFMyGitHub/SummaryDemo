package com.longf.module_me.fragment;

import android.view.View;

import com.longf.lib_common.mvp.BaseRefreshFragment;
import com.longf.module_me.R;

import java.util.List;

public class MainMeFragment extends BaseRefreshFragment {

    public static MainMeFragment newInstance() {
        return new MainMeFragment();
    }

    @Override
    protected int onBindRreshLayout() {
        return 0;
    }

    @Override
    public void injectPresenter() {

    }

    @Override
    public int onBindLayout() {
        return R.layout.fragment_me_main;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }

    @Override
    public String getToolbarTitle() {
        return "我的";
    }

    @Override
    public void refreshData(List data) {

    }

    @Override
    public void loadMoreData(List data) {

    }

    @Override
    public void onRefreshEvent() {

    }

    @Override
    public void onLoadMoreEvent() {

    }

    @Override
    public void onAutoLoadEvent() {

    }
}
